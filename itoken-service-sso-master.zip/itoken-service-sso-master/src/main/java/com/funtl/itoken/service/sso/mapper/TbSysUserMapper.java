package com.funtl.itoken.service.sso.mapper;

import com.funtl.itoken.common.domain.TbSysUser;
import tk.mybatis.mapper.MyMapper;

public interface TbSysUserMapper extends MyMapper<TbSysUser> {
}