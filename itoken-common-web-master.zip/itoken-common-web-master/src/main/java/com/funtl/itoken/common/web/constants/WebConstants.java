package com.funtl.itoken.common.web.constants;

/**
 * @author 李洋
 * @date 2019-09-03 17:32
 */
public class WebConstants {
    public static final String SESSION_USER = "admin";
    public static final String SESSION_TOKEN = "token";
}
