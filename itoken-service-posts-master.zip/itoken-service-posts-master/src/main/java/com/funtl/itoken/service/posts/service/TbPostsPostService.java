package com.funtl.itoken.service.posts.service;

import com.funtl.itoken.common.domain.BaseDomain;
import com.funtl.itoken.common.service.service.BaseService;

/**
 * @author 李洋
 * @date 2019-08-31 14:40
 */
public interface TbPostsPostService<T extends BaseDomain> extends BaseService<T> {
}
