package com.funtl.itoken.service.admin.mapper;

import com.funtl.itoken.common.domain.TbSysUser;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.MyMapper;

/**
 * @author 李洋
 * @date 2019-08-31 10:20
 */
@Repository
public interface TbSysUserExtendMapper extends MyMapper<TbSysUser> {
}
