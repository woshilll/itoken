package com.funtl.itoken.service.admin.service;


import com.funtl.itoken.common.domain.BaseDomain;
import com.funtl.itoken.common.domain.TbSysUser;
import com.funtl.itoken.common.service.service.BaseService;

/**
 * @author 李洋
 * @date 2019-08-27 10:47
 */
public interface AdminService<T extends BaseDomain> extends BaseService<T> {
}
